import pandas as pd 
import openpyxl as opl 
import sys 
from pathlib import Path 
from openpyxl.styles import Font 

Caminho_enviados = Path(r"K:\Orçamento\2026\2. Despesas\2.1 Planilhas de Despesas\2.1.1 Arquivos enviados")
Caminho_recebidos = Path(r"K:\Orçamento\2026\2. Despesas\2.1 Planilhas de Despesas\2.1.2 Arquivos recebidos")

arquivo_pronto = (r"K:\Administrativo Financeiro\Controladoria\GMD\2025\Qlik\Monitoramento\Form_despesas_contagem\controle_arquivos_formdespesa.xlsx")

nome_celula = "Contagem"

def pasta_recursivo(pasta_base, status, area):
    try: 
        for arquivo in pasta_base.rglob('*'): #Pega todos os arquivos em todas as subpastas 
            if arquivo.is_file():
                yield[str(arquivo), arquivo.name, area, status]
    except Exception as e: 
        print(f"Erro ao processar {pasta_base}: {e}")

def main():
    lista_de_dados = []
    if Caminho_enviados.exists():
        for pasta_area in Caminho_enviados.iterdir():  #Para visualizar todos os subdiretórios dentro de um diretório específico
            if pasta_area.is_dir(): # verifica se um caminho de arquivo fornecido é um diretório 
                area = pasta_area.name
                print(f"Processando [Enviado] - Area: {area}")
                lista_de_dados.extend(list(pasta_recursivo(pasta_area, "Enviado", area)))
    else: 
        print(f"Erro: Caminho de ENVIADOS não encontrado")

    if Caminho_recebidos.exists():
        for pasta_area in Caminho_recebidos.iterdir():
            if pasta_area.is_dir(): 
                area = pasta_area.name
                pasta_v1 = pasta_area / "V1"

                if pasta_v1.exists() and pasta_v1.is_dir():
                    print(f"Processando [Recebidos] - Area: {area} (V1)")
                    
                    lista_de_dados.extend(list(pasta_recursivo(pasta_v1, "Recebido", area)))
    else: 
        print(f"Erro: Caminho de RECEBIDOS não encontrado ")

    if not lista_de_dados:
        print('Nenhum arquivo encontrado')
        return
    
    df = pd.DataFrame(lista_de_dados, columns=["Caminho Completo", 'Nome arquivo', 'Area', 'Status'])

    print(f'Salvando {len(df)} registros em {arquivo_pronto} na aba {nome_celula}')
    try: 
        with pd.ExcelWriter(arquivo_pronto, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
            df.to_excel(writer, sheet_name=nome_celula, index=False)
            ws = writer.sheets[nome_celula]
            ws.row_dimensions[1].font = Font(bold=True)

        print("Atualização concluída com sucesso.")

    except PermissionError:
        print(f"ERRO DE PERMISSÃO: O arquivo {arquivo_pronto} está aberto por outro usuário.")
        print("A atualização falhou.")
    except Exception as e:
        print(f"Erro ao salvar o arquivo Excel: {e}")
        
if __name__ == "__main__":
    main()